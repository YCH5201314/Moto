package csp;

import org.junit.Test;

public class JUnitTest {
	@Test
	public void testAccount() {
		
	}
}
